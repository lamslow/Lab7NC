package com.example.lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Bai2Activity extends AppCompatActivity {
    ImageView imgSlide;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_bai2);
        imgSlide = findViewById(R.id.imgSlide);

    }

    public void showAll(View view) {
        showImage("All");
    }

    public void showDoraemon(View view) {
        showImage("Doraemon");
    }

    public void showNobita(View view) {
        showImage("Nobita");
    }

    private void showImage(final String img) {
        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(imgSlide, "translationX", 0f, 500f);
        objectAnimator.setDuration(700);
        ObjectAnimator objectAnimator2 = ObjectAnimator.ofFloat(imgSlide, "alpha", 1f, 0f);
        objectAnimator2.setDuration(700);
        ObjectAnimator objectAnimator3 = ObjectAnimator.ofFloat(imgSlide, "translationX", -500f, 0f);
        objectAnimator3.setDuration(700);
        ObjectAnimator objectAnimator4 = ObjectAnimator.ofFloat(imgSlide, "alpha", 0f, 1f);
        objectAnimator4.setDuration(700);


        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(objectAnimator3).with(objectAnimator4).after(objectAnimator).after(objectAnimator2);
        animatorSet.start();


        final String imgName = img;
        objectAnimator2.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (imgName == "Nobita") {
                    imgSlide.setImageResource(R.drawable.nobita);
                }
                if (imgName == "Doraemon") {
                    imgSlide.setImageResource(R.drawable.doraemon);
                }
                if (imgName == "All") {
                    imgSlide.setImageResource(R.drawable.all);
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });


    }
}
