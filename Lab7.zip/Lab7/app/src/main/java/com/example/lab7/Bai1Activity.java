package com.example.lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Bai1Activity extends AppCompatActivity {
    ImageView imgData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai1);
        imgData=findViewById(R.id.imgView);
    }

    public void rotationImg(View view) {
        ObjectAnimator objectAnimator=ObjectAnimator.ofFloat(imgData,"rotation",0f,360f);
        objectAnimator.setDuration(2000);
        objectAnimator.setRepeatCount(0);
        objectAnimator.start();

    }

    public void zoomImg(View view) {
        Animator animator= AnimatorInflater.loadAnimator(this,R.animator.zoom);
        animator.setTarget(imgData);
        animator.start();
    }

    public void moveImg(View view) {
        ObjectAnimator objectAnimator=ObjectAnimator.ofFloat(imgData,"translationX",0f,360f);
        objectAnimator.setDuration(1000);
        objectAnimator.setRepeatCount(1);
        objectAnimator.setRepeatMode(ValueAnimator.REVERSE);
        objectAnimator.start();
    }
}
